# ===== Subject =====

class WeatherStation:
    def __init__(self):
        self._observers = []  # тіркелген бақылаушылар
        self._temperature = None

    def attach(self, observer):
        self._observers.append(observer)

    def detach(self, observer):
        self._observers.remove(observer)

    def notify(self):
        for observer in self._observers:
            observer.update(self._temperature)

    def set_temperature(self, temp):
        print(f"\nWeatherStation: Temperature changed to {temp}°C")
        self._temperature = temp
        self.notify()


# ===== Observers =====

class PhoneDisplay:
    def update(self, temperature):
        print(f"PhoneDisplay: Current temperature is {temperature}°C. (Checking from phone app)")

class TVDisplay:
    def update(self, temperature):
        print(f"TVDisplay: Temperature alert! {temperature}°C on TV screen.")


# ===== DEMO =====

station = WeatherStation()

phone = PhoneDisplay()
tv = TVDisplay()

# тіркелу
station.attach(phone)
station.attach(tv)

# температура өзгерісін хабарлау
station.set_temperature(25)
station.set_temperature(30)

# телефон дисплейді өшіру
station.detach(phone)

# тек TV хабар алады
station.set_temperature(35)
