# ===== Singleton for log storage =====
class LogStorage:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(LogStorage, cls).__new__(cls)
            cls._instance.logs = []
        return cls._instance

    def add_log(self, message):
        self.logs.append(message)

    def get_logs(self):
        return self.logs


# ===== Observer interface and concrete subscribers =====
class LogSubscriber:
    def update(self, log_message):
        raise NotImplementedError("update() must be implemented")


class ConsoleSubscriber(LogSubscriber):
    def update(self, log_message):
        print(f"[Console] {log_message}")


class FileSubscriber(LogSubscriber):
    def update(self, log_message):
        # For demo, just print simulation
        print(f"[File] Writing to file: {log_message}")


class EmailSubscriber(LogSubscriber):
    def update(self, log_message):
        # For demo, just print simulation
        print(f"[Email] Sending email: {log_message}")


# ===== Factory to create subscribers =====
class SubscriberFactory:
    _types = {
        "console": ConsoleSubscriber,
        "file": FileSubscriber,
        "email": EmailSubscriber
    }

    @classmethod
    def create_subscriber(cls, type_):
        if type_ not in cls._types:
            raise ValueError(f"Unknown subscriber type: {type_}")
        return cls._types[type_]()  # return instance


# ===== Subject =====
class LoggerSubject:
    def __init__(self):
        self._subscribers = []

    def attach(self, subscriber: LogSubscriber):
        self._subscribers.append(subscriber)

    def detach(self, subscriber: LogSubscriber):
        self._subscribers.remove(subscriber)

    def notify(self, log_message):
        for subscriber in self._subscribers:
            subscriber.update(log_message)
        # Also save to central storage
        LogStorage().add_log(log_message)


# ===== DEMO =====

# Create logger subject
logger = LoggerSubject()

# Create subscribers via factory
console = SubscriberFactory.create_subscriber("console")
file_sub = SubscriberFactory.create_subscriber("file")
email_sub = SubscriberFactory.create_subscriber("email")

# Attach subscribers
logger.attach(console)
logger.attach(file_sub)
logger.attach(email_sub)

# Add logs
logger.notify("Application started")
logger.notify("User logged in")
logger.notify("Error: Invalid input")

# Access centralized log storage
storage = LogStorage()
print("\nAll logs stored centrally:")
print(storage.get_logs())
