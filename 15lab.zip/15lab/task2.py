class DiscountStrategy:
    def apply(self, price):
        raise NotImplementedError("apply() must be implemented")


class NoDiscount(DiscountStrategy):
    def apply(self, price):
        return price


class PercentageDiscount(DiscountStrategy):
    def __init__(self, percent):
        self.percent = percent

    def apply(self, price):
        return price - (price * self.percent / 100)


class FixedDiscount(DiscountStrategy):
    def __init__(self, amount):
        self.amount = amount

    def apply(self, price):
        return max(0, price - self.amount)


def calculate_total(price, strategy: DiscountStrategy):
    return strategy.apply(price)


# ==== DEMO ====

price = 1000

# 1. No discount
strategy = NoDiscount()
print("No Discount:", calculate_total(price, strategy))

# 2. 20% discount
strategy = PercentageDiscount(20)
print("20% Discount:", calculate_total(price, strategy))

# 3. 150 fixed discount
strategy = FixedDiscount(150)
print("Fixed 150 Discount:", calculate_total(price, strategy))
