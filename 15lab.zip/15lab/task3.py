class Car:
    def drive(self):
        raise NotImplementedError("drive() must be implemented")


class Sedan(Car):
    def drive(self):
        print("Driving a sedan — smooth and comfortable!")


class SUV(Car):
    def drive(self):
        print("Driving an SUV — powerful and spacious!")


class Truck(Car):
    def drive(self):
        print("Driving a truck — heavy-duty mode!")


class CarFactory:
    _creators = {}

    @classmethod
    def register(cls, key, creator):
        cls._creators[key] = creator

    @classmethod
    def get(cls, key):
        creator = cls._creators.get(key)
        if not creator:
            raise ValueError(f"Unknown car type: {key}")
        return creator()


CarFactory.register("sedan", Sedan)
CarFactory.register("suv", SUV)
CarFactory.register("truck", Truck)


# ==== DEMO (must run!) ====

factory = CarFactory

car1 = factory.get("sedan")
car2 = factory.get("suv")
car3 = factory.get("truck")

car1.drive()
car2.drive()
car3.drive()
