import datetime

class Logger:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(Logger, cls).__new__(cls)
            cls._instance.logs = []
        return cls._instance

    def log(self, message):
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.logs.append(f"[{timestamp}] {message}")


# ==== DEMO ====

logger1 = Logger()
logger2 = Logger()

logger1.log("System started")
logger2.log("User logged in")

print("Logger1 logs:", logger1.logs)
print("Logger2 logs:", logger2.logs)

print("Same instance:", logger1 is logger2)
